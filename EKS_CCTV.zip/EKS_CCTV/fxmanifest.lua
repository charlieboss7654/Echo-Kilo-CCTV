fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'EKS CCTV'
author 'Cowboy - Echo Kilo Studios'
description 'Live CCTV Script!'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'shared/config.lua',
}

client_scripts {
    'client/main.lua',
}

server_scripts {
    'server/main.lua',
}
