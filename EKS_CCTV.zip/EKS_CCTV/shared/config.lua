Config = {}

-- Third-eye (ox_target) only
Config.UseTarget = true

-- Keys
Config.Keys = {
    left    = 174,  -- ?
    right   = 175,  -- ?
    up      = 172,  -- ?
    down    = 173,  -- ?
    zoomIn  = 44,   -- Q
    zoomOut = 38,   -- E
    next    = 249,  -- N
    exit    = 177   -- BACKSPACE
}

-- Camera tuning
Config.Zoom = { minFov = 30.0, maxFov = 90.0, step = 3.0 }
Config.RotateSpeed = { yaw = 1.7, pitch = 1.2 }
Config.PitchLimits = { min = -89.0, max = 25.0 }
Config.YawLimit = 90.0  -- � degrees around camera.heading

-- Desks + cameras
Config.Desks = {
    {
        id = 'mrpd_frontdesk',
        label = 'MRPD Security Desk',
        coords = vec3(441.95, -981.95, 30.69),
        radius = 1.9,
        cameras = {
            {
                id = 'mrpd_entrance',
                label = 'Front Entrance',
                coords = vec3(444.96, -974.59, 33.02),
                rot    = vec3(-12.0, 0.0, 180.0),
                heading = 180.0,
                fov    = 60.0
            },
            {
                id = 'mrpd_lobby',
                label = 'Main Lobby',
                coords = vec3(441.50, -985.80, 34.50),
                rot    = vec3(-15.0, 0.0, -90.0),
                heading = -90.0,
                fov    = 60.0
            },
            {
                id = 'mrpd_cells',
                label = 'Holding Cells',
                coords = vec3(481.50, -1004.00, 27.50),
                rot    = vec3(-10.0, 0.0, 90.0),
                heading = 90.0,
                fov    = 60.0
            }
        }
    },
    {
        id = 'pillbox_security',
        label = 'Pillbox CCTV Desk',
        coords = vec3(311.20, -592.70, 43.28),
        radius = 1.8,
        cameras = {
            {
                id = 'pillbox_lobby',
                label = 'Hospital Lobby',
                coords = vec3(307.5, -592.0, 46.8),
                rot    = vec3(-12.0, 0.0, 160.0),
                heading = 160.0,
                fov    = 60.0
            }
        }
    }
}

-- UI text (short, smooth, and to the point)
Config.Text = {
    open_live   = 'View CCTV',
    no_cameras  = 'No cameras on this desk.',
    controls    = 'Arrows: Pan   Q/E: Zoom   N: Next Camera   Backspace: Exit',
    live_title  = 'Live CCTV: %s (%d/%d)',
}
