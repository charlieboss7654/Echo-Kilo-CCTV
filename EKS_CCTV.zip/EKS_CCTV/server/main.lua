lib.callback.register('eks_cctv:svNow', function(_)
    return os.date('%Y-%m-%d %H:%M:%S')
end)
