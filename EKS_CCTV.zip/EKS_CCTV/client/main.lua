local desks = Config.Desks or {}
local zones = {}
local activeLive = false
local camHandle = nil
local currentDeskId = nil
local currentCamIdx = 1
local yaw, pitch, fov = 0.0, 0.0, 60.0
local baseYaw = 0.0
local yawLimit = Config.YawLimit or 90.0
local currentCamLabel = ""
local serverClock = ""
local clockThread = nil

local function drawText(x, y, text, scale, center, alpha)
    if not text or text == '' then return end
    SetTextFont(0)
    SetTextScale(scale or 0.36, scale or 0.36)
    SetTextColour(255, 255, 255, alpha or 230)
    SetTextOutline()
    SetTextCentre(center and true or false)
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(x, y)
end

local function startClock()
    if clockThread then return end
    clockThread = CreateThread(function()
        while activeLive do
            serverClock = lib.callback.await('eks_cctv:svNow', false) or ""
            Wait(1000)
        end
        clockThread = nil
    end)
end

local function drawCCTVHud(camLabel, idx, total)
    local title = (Config.Text.live_title or "Live CCTV: %s (%d/%d)"):format(camLabel or "Camera", idx or 1, total or 1)
    drawText(0.014, 0.015, title, 0.40, false, 235)
    local ts = serverClock or ""
    if ts ~= "" then
        local len = string.len(ts) * 0.0062
        drawText(0.988 - len, 0.015, ts, 0.40, false, 235)
    end
    drawText(0.50, 0.925, Config.Text.controls or "", 0.38, true, 245)
end

local function angNorm(a)
    a = a % 360.0
    if a > 180.0 then a = a - 360.0 end
    if a < -180.0 then a = a + 360.0 end
    return a
end

local function clampYawToLimit(y)
    local diff = angNorm(y - baseYaw)
    if diff > yawLimit then return baseYaw + yawLimit end
    if diff < -yawLimit then return baseYaw - yawLimit end
    return y
end

CreateThread(function()
    Wait(200)
    for _, d in ipairs(desks) do
        if Config.UseTarget then
            local options = {
                {
                    name = ('eks_cctv:%s:live'):format(d.id),
                    icon = 'fa-solid fa-video',
                    label = Config.Text.open_live,
                    onSelect = function()
                        if not d.cameras or #d.cameras == 0 then
                            lib.notify({ type = 'error', description = Config.Text.no_cameras })
                            return
                        end
                        openLive(d.id)
                    end
                }
            }
            local ok = pcall(function()
                return exports.ox_target:addSphereZone({
                    name = ('eks_cctv:%s'):format(d.id),
                    coords = d.coords,
                    radius = d.radius or 1.8,
                    debug = Config.DebugZones or false,
                    drawSprite = Config.DebugZones or false,
                    options = options
                })
            end)
            if not ok then
                pcall(function()
                    return exports.ox_target:addSphereZone(
                        d.coords,
                        d.radius or 1.8,
                        { name = ('eks_cctv:%s'):format(d.id), debug = Config.DebugZones or false, drawSprite = Config.DebugZones or false, options = options }
                    )
                end)
            end
        end
    end
end)

local liveWantsNext = false
RegisterCommand('cctv_nextcam', function() if activeLive then liveWantsNext = true end end, false)
RegisterKeyMapping('cctv_nextcam', 'CCTV: Next Camera', 'keyboard', 'N')

local function setCamFor(deskId, idx)
    local d
    for _, desk in ipairs(desks) do
        if desk.id == deskId then d = desk break end
    end
    if not d then return end
    local cams = d.cameras
    if not cams or not cams[idx] then return end
    local cam = cams[idx]

    if not camHandle then
        camHandle = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
    end

    SetCamCoord(camHandle, cam.coords.x, cam.coords.y, cam.coords.z)
    pitch = cam.rot.x
    baseYaw = cam.heading or cam.rot.z
    yaw   = baseYaw
    fov   = cam.fov or 60.0
    SetCamRot(camHandle, pitch, 0.0, yaw, 2)
    SetCamFov(camHandle, fov)

    RenderScriptCams(true, false, 0, true, true)
    SetTimecycleModifier('scanline_cam_cheap')
    SetTimecycleModifierStrength(1.0)
    DisplayRadar(false)

    currentCamLabel = cam.label or cam.id
end

local function nextCamera()
    if not currentDeskId then return end
    local cams
    for _, d in ipairs(desks) do
        if d.id == currentDeskId then cams = d.cameras break end
    end
    if not cams or #cams == 0 then return end
    currentCamIdx = currentCamIdx + 1
    if currentCamIdx > #cams then currentCamIdx = 1 end
    setCamFor(currentDeskId, currentCamIdx)
end

local function cleanupCam()
    if camHandle then
        RenderScriptCams(false, false, 0, true, true)
        DestroyCam(camHandle, false)
        camHandle = nil
    end
    ClearTimecycleModifier()
    DisplayRadar(true)
    activeLive = false
    currentDeskId = nil
    local ped = PlayerPedId()
    FreezeEntityPosition(ped, false)
    SetEntityInvincible(ped, false)
end

function openLive(deskId)
    if activeLive then cleanupCam() end
    activeLive = true
    currentDeskId = deskId
    currentCamIdx = 1
    setCamFor(deskId, currentCamIdx)
    startClock()
    local ped = PlayerPedId()
    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)

    CreateThread(function()
        while activeLive do
            DisableAllControlActions(0)
            DisableAllControlActions(1)
            DisableAllControlActions(2)
            DisableControlAction(0, 44, true)
            DisableControlAction(0, 36, true)

            local changed = false
            if IsDisabledControlPressed(0, Config.Keys.left)  then yaw   = yaw - Config.RotateSpeed.yaw;   changed = true end
            if IsDisabledControlPressed(0, Config.Keys.right) then yaw   = yaw + Config.RotateSpeed.yaw;   changed = true end
            if IsDisabledControlPressed(0, Config.Keys.up)    then pitch = math.max(Config.PitchLimits.min, pitch - Config.RotateSpeed.pitch); changed = true end
            if IsDisabledControlPressed(0, Config.Keys.down)  then pitch = math.min(Config.PitchLimits.max, pitch + Config.RotateSpeed.pitch); changed = true end
            if IsDisabledControlJustPressed(0, Config.Keys.zoomIn)  then fov = math.max(Config.Zoom.minFov, fov - Config.Zoom.step); changed = true end
            if IsDisabledControlJustPressed(0, Config.Keys.zoomOut) then fov = math.min(Config.Zoom.maxFov, fov + Config.Zoom.step); changed = true end

            yaw = clampYawToLimit(yaw)

            if liveWantsNext then
                liveWantsNext = false
                nextCamera()
                changed = false
            end

            if IsDisabledControlJustPressed(0, Config.Keys.exit) then
                cleanupCam()
                break
            end

            if changed and camHandle then
                SetCamRot(camHandle, pitch, 0.0, yaw, 2)
                SetCamFov(camHandle, fov)
            end

            local total = 1
            for _, d in ipairs(desks) do if d.id == currentDeskId then total = #d.cameras break end end
            drawCCTVHud(currentCamLabel, currentCamIdx, total)

            Wait(0)
        end
    end)
end
